#!/usr/bin/env python3
"""SPS Daily Feed Collector (v2: high-signal intake + hard quality gates)

Editable config files:
  - config/spsdaily_feeds.json
  - config/spsdaily_quality.json
  - config/spsdaily_source_weights.json
"""

from __future__ import annotations

import os, re, json, math, html, sqlite3, socket
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlparse

import feedparser
import requests

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
CONFIG_DIR = ROOT / "config"
DATA_DIR.mkdir(parents=True, exist_ok=True)
CONFIG_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "articles.db"
PENDING_FILE = DATA_DIR / "pending_articles.json"

FEEDS_FILE = CONFIG_DIR / "spsdaily_feeds.json"
QUALITY_FILE = CONFIG_DIR / "spsdaily_quality.json"
WEIGHTS_FILE = CONFIG_DIR / "spsdaily_source_weights.json"

BOT_TOKEN = os.getenv("SPSDAILY_BOT_TOKEN", "").strip()
CHAT_ID = os.getenv("SPSDAILY_CHAT_ID", "").strip()
TELEGRAM_API = f"https://api.telegram.org/bot{BOT_TOKEN}" if BOT_TOKEN else ""

DEFAULT_FEEDS = {
  "science": [
    ["Quanta Magazine","https://api.quantamagazine.org/feed/"],
    ["Knowable Magazine","https://knowablemagazine.org/rss"],
    ["Undark","https://undark.org/feed/"],
    ["Nautilus","https://nautil.us/feed/"],
    ["Science Magazine - News","https://www.science.org/rss/news_current.xml"],
    ["PNAS","https://www.pnas.org/action/showFeed?type=etoc&feed=rss&jc=pnas"],
    ["eLife","https://elifesciences.org/rss.xml"],
    ["Phys.org","https://phys.org/rss-feed/"]
  ],
  "philosophy": [
    ["Aeon","https://aeon.co/feed.rss"],
    ["NDPR","https://ndpr.nd.edu/feed/"],
    ["Daily Nous","https://dailynous.com/feed/"],
    ["The Point","https://thepointmag.com/feed/"],
    ["The Hedgehog Review","https://hedgehogreview.com/feed"],
    ["Public Domain Review","https://publicdomainreview.org/rss.xml"]
  ],
  "society": [
    ["Noema","https://www.noemamag.com/feed/"],
    ["Boston Review","https://bostonreview.net/feed/"],
    ["The Atlantic","https://www.theatlantic.com/feed/all/"],
    ["JSTOR Daily","https://daily.jstor.org/feed/"],
    ["Pew Research Center","https://www.pewresearch.org/feed/"],
    ["Project Syndicate","https://www.project-syndicate.org/rss"]
  ],
  "books": [
    ["NYRB","https://www.nybooks.com/feed/"],
    ["LRB","https://www.lrb.co.uk/rss"],
    ["The New Yorker - Books","https://www.newyorker.com/feed/books"],
    ["Los Angeles Review of Books","https://lareviewofbooks.org/feed/"]
  ]
}

DEFAULT_QUALITY = {
  "max_age_days": 7,
  "select_per_category": int(os.getenv("SPSDAILY_SELECT_PER_CATEGORY","12")),
  "overfetch_factor": 3,
  "timeout_sec": 20,
  "user_agent": "SPSDailyCollector/2.0 (+https://thebeakers.com)",
  "min_words": {"science":650, "philosophy":900, "society":900, "books":750},
  "domain_min_words": {"phys.org":900, "sciencedaily.com":1000},
  "domain_blocklist": ["psychologytoday.com","medium.com","towardsdatascience.com","linkedin.com","facebook.com","instagram.com","tiktok.com"],
  "clickbait_patterns": [
    r"^\s*\d+\s+(ways|things|reasons|signs|habits)\b",
    r"\b(you won\'t believe|mind[-\s]?blowing|shocking|secret|this one trick|life[-\s]?changing)\b",
    r"\b(what you need to know|here\'s why|here is why|the truth about)\b",
    r"\b(hack|hacks|tips and tricks|simple trick)\b",
    r"\b(are we wrong|everything you thought|destroyed|obliterated)\b"
  ]
}

DEFAULT_WEIGHTS = {
  "domain_weight": {
    "aeon.co":3, "ndpr.nd.edu":3, "dailynous.com":2, "noemamag.com":3,
    "knowablemagazine.org":3, "undark.org":2, "api.quantamagazine.org":3,
    "science.org":2, "pnas.org":2, "elifesciences.org":2, "phys.org":-2
  },
  "source_weight": {}
}

def load_json(path: Path, fallback: dict) -> dict:
  if path.exists():
    try:
      return json.loads(path.read_text())
    except Exception:
      return fallback
  return fallback

def normalize_domain(url: str) -> str:
  try:
    d = urlparse(url).netloc.lower()
    return d[4:] if d.startswith("www.") else d
  except Exception:
    return ""

def clean_text(s: str) -> str:
  s = html.unescape(s or "")
  return re.sub(r"\s+"," ",s).strip()

def parse_entry_date(entry):
  for key in ("published_parsed","updated_parsed"):
    t = getattr(entry, key, None)
    if t:
      try: return datetime(*t[:6], tzinfo=timezone.utc)
      except Exception: pass
  return None

def looks_clickbaity(text: str, patterns: list[str]) -> bool:
  t = (text or "").lower()
  return any(re.search(p, t, flags=re.IGNORECASE) for p in patterns)

def init_db() -> sqlite3.Connection:
  conn = sqlite3.connect(DB_PATH)
  conn.execute("""CREATE TABLE IF NOT EXISTS seen_articles(
    url TEXT PRIMARY KEY, headline TEXT, category TEXT, seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
  conn.commit()
  return conn

def already_seen(conn, url: str) -> bool:
  return conn.execute("SELECT 1 FROM seen_articles WHERE url=?", (url,)).fetchone() is not None

def mark_seen(conn, url: str, headline: str, category: str):
  conn.execute("INSERT OR IGNORE INTO seen_articles(url,headline,category) VALUES (?,?,?)", (url,headline,category))
  conn.commit()

def fetch_wordcount(url: str, timeout_sec: int, user_agent: str) -> int:
  try:
    r = requests.get(url, timeout=timeout_sec, headers={"User-Agent": user_agent})
    if r.status_code >= 400 or not r.text: return 0
    h = re.sub(r"(?is)<(script|style|noscript)[^>]*>.*?</\1>", " ", r.text)
    txt = re.sub(r"(?is)<[^>]+>", " ", h)
    txt = re.sub(r"\s+"," ", html.unescape(txt)).strip()
    return len(re.findall(r"[A-Za-z0-9][A-Za-z0-9'\-]*", txt))
  except Exception:
    return 0

def telegram_send(msg: str):
  if not (BOT_TOKEN and CHAT_ID): return
  try:
    requests.post(f"{TELEGRAM_API}/sendMessage",
      json={"chat_id": CHAT_ID, "text": msg, "parse_mode": "HTML", "disable_web_page_preview": True},
      timeout=10)
  except Exception:
    pass

@dataclass
class Cand:
  category: str
  source: str
  url: str
  domain: str
  headline: str
  teaser: str
  published: str
  base: float
  wc: int = 0
  score: float = 0.0

def base_score(c: Cand, weights: dict) -> float:
  dw = weights.get("domain_weight", {}).get(c.domain, 0)
  sw = weights.get("source_weight", {}).get(c.source, 0)
  teaser_pen = 0 if (c.teaser and len(c.teaser) >= 80) else -0.5
  return float(dw + sw + teaser_pen)

def final_score(b: float, wc: int) -> float:
  return b + (math.log(max(wc,50),10) if wc else 0.0)

def main():
  feeds = load_json(FEEDS_FILE, DEFAULT_FEEDS)
  q = load_json(QUALITY_FILE, DEFAULT_QUALITY)
  w = load_json(WEIGHTS_FILE, DEFAULT_WEIGHTS)

  cutoff = datetime.now(timezone.utc) - timedelta(days=int(q.get("max_age_days",7)))
  select_n = int(q.get("select_per_category",12))
  overfetch = int(q.get("overfetch_factor",3))
  timeout = int(q.get("timeout_sec",20))
  ua = str(q.get("user_agent", DEFAULT_QUALITY["user_agent"]))
  min_words = dict(q.get("min_words", DEFAULT_QUALITY["min_words"]))
  domain_min = dict(q.get("domain_min_words", DEFAULT_QUALITY["domain_min_words"]))
  block = set(d.lower().strip() for d in q.get("domain_blocklist", []))
  pats = list(q.get("clickbait_patterns", []))

  conn = init_db()
  cand = {k: [] for k in feeds.keys()}

  for cat, flist in feeds.items():
    for source, feed_url in flist:
      fp = feedparser.parse(feed_url)
      for e in (getattr(fp, "entries", []) or []):
        url = clean_text(getattr(e, "link", "") or "")
        if not url: continue
        dom = normalize_domain(url)
        if not dom or dom in block: continue
        title = clean_text(getattr(e, "title", "") or "")
        summ = clean_text(getattr(e, "summary", "") or getattr(e,"description","") or "")
        if looks_clickbaity(title, pats) or looks_clickbaity(summ, pats): continue
        dt = parse_entry_date(e)
        if dt and dt < cutoff: continue
        if already_seen(conn, url): continue

        c = Cand(cat, source, url, dom, title, summ[:280], dt.isoformat() if dt else "", 0.0)
        c.base = base_score(c, w)
        cand[cat].append(c)

  staged = {}
  for cat, items in cand.items():
    items.sort(key=lambda x: x.base, reverse=True)
    staged[cat] = items[:max(select_n*overfetch, select_n)]

  kept = {k: [] for k in feeds.keys()}
  dropped_short = 0

  for cat, items in staged.items():
    cat_min = int(min_words.get(cat, 800))
    for c in items:
      req = int(domain_min.get(c.domain, cat_min))
      c.wc = fetch_wordcount(c.url, timeout, ua)
      if c.wc < req:
        dropped_short += 1
        continue
      c.score = final_score(c.base, c.wc)
      kept[cat].append({
        "headline": c.headline,
        "teaser": c.teaser,
        "url": c.url,
        "source": c.source,
        "domain": c.domain,
        "published": c.published,
        "word_count": c.wc,
        "reading_min": int(round(c.wc/220)) if c.wc else None,
        "score": round(c.score, 3),
      })

    kept[cat].sort(key=lambda x: x.get("score",0), reverse=True)
    kept[cat] = kept[cat][:select_n]
    for it in kept[cat]:
      mark_seen(conn, it["url"], it["headline"], cat)

  PENDING_FILE.write_text(json.dumps(kept, indent=2))
  host = socket.gethostname()
  now = datetime.now().strftime("%Y-%m-%d %H:%M")
  total = sum(len(v) for v in kept.values())
  msg = (f"🧪 <b>SPSDaily Collector</b>\n<b>Host:</b> {html.escape(host)}\n<b>Time:</b> {html.escape(now)}\n"
         f"<b>Pending:</b> {total} (Sci {len(kept.get('science',[]))}, Phil {len(kept.get('philosophy',[]))}, "
         f"Soc {len(kept.get('society',[]))}, Books {len(kept.get('books',[]))})\n"
         f"<b>Dropped (short):</b> {dropped_short}\nNext: run telegram_curator.py")
  telegram_send(msg)
  print(msg.replace("<b>","").replace("</b>",""))

if __name__ == "__main__":
  main()

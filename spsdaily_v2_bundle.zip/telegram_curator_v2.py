#!/usr/bin/env python3
"""SPS Daily Telegram Curator (v2)"""

from __future__ import annotations

import os, json, time, html
from pathlib import Path
from urllib.parse import urlparse
import requests

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

PENDING_FILE = DATA_DIR / "pending_articles.json"

BOT_TOKEN = os.getenv("SPSDAILY_BOT_TOKEN","").strip()
CHAT_ID = os.getenv("SPSDAILY_CHAT_ID","").strip()
if not (BOT_TOKEN and CHAT_ID):
  raise SystemExit("Missing SPSDAILY_BOT_TOKEN or SPSDAILY_CHAT_ID")

API = f"https://api.telegram.org/bot{BOT_TOKEN}"

def normalize_domain(url: str) -> str:
  try:
    d = urlparse(url).netloc.lower()
    return d[4:] if d.startswith("www.") else d
  except Exception:
    return ""

def send(text: str, preview: bool = True):
  requests.post(f"{API}/sendMessage", json={
    "chat_id": CHAT_ID, "text": text, "parse_mode": "HTML",
    "disable_web_page_preview": (not preview)
  }, timeout=20)

def send_article(a: dict, cat: str, idx: int):
  title = html.escape(a.get("headline",""))
  teaser = html.escape(a.get("teaser",""))
  url = a.get("url","")
  source = html.escape(a.get("source",""))
  domain = html.escape(a.get("domain") or normalize_domain(url))
  wc = a.get("word_count")
  rmin = a.get("reading_min")
  score = a.get("score")

  meta = []
  if wc: meta.append(f"{wc} words")
  if rmin is not None: meta.append(f"~{rmin} min")
  if score is not None: meta.append(f"score {score}")
  meta_line = f"<i>{html.escape(' • '.join(meta))}</i>\n" if meta else ""

  text = (f"<b>[{cat.upper()} #{idx+1}]</b> {title}\n"
          f"{meta_line}"
          f"<b>Source:</b> {source} ({domain})\n"
          f"{teaser}\n\n{html.escape(url)}")

  keyboard = {"inline_keyboard":[[
    {"text":"✅ Approve","callback_data":f"approve|{cat}|{idx}"},
    {"text":"❌ Reject","callback_data":f"reject|{cat}|{idx}"},
    {"text":"⭐ Editors Pick","callback_data":f"star|{cat}|{idx}"},
  ]]}
  requests.post(f"{API}/sendMessage", json={
    "chat_id": CHAT_ID, "text": text, "parse_mode": "HTML",
    "reply_markup": keyboard
  }, timeout=30)

def main():
  if not PENDING_FILE.exists():
    send("❌ No pending_articles.json found. Run feed_collector.py first.", preview=False)
    return
  pending = json.loads(PENDING_FILE.read_text())
  send("🗞️ <b>SPS Daily - Review Queue</b>\nTap ✅ approve, ❌ reject, ⭐ editor's pick.", preview=False)

  total = 0
  for cat in ["science","philosophy","society","books"]:
    items = pending.get(cat, []) or []
    for idx, a in enumerate(items):
      send_article(a, cat, idx)
      total += 1
      time.sleep(0.25)

  send(f"✅ <b>Sent {total} items</b>. Use buttons to curate.", preview=False)

if __name__ == "__main__":
  main()
